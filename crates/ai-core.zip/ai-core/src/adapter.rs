use anyhow::Result;
use async_trait::async_trait;
use serde::{Deserialize, Serialize};

pub mod adapters;
pub use adapters::{
    anthropic::{AnthropicAdapter, AnthropicConfig, AnthropicMessage, ContentBlock},
    google::{GoogleAdapter, GoogleConfig, GoogleContent, GooglePart},
    openai::{OpenAIAdapter, OpenAIConfig, OpenAIMessage},
};

/// Unified adapter configuration supporting all providers
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "provider")]
pub enum AdapterConfig {
    OpenAI(OpenAIConfig),
    Anthropic(AnthropicConfig),
    Google(GoogleConfig),
}

/// Response chunk for streaming
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResponseChunk {
    pub text: String,
    pub finish_reason: Option<String>,
    pub metadata: serde_json::Value,
}

/// Explanation result
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Explanation {
    pub summary: String,
    pub details: Vec<String>,
    pub examples: Vec<String>,
}

/// Options for prediction
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PredictOptions {
    pub max_tokens: Option<usize>,
    pub temperature: Option<f32>,
    pub stop_sequences: Vec<String>,
}

/// Usage information
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Usage {
    pub input_tokens: usize,
    pub output_tokens: usize,
    pub total_tokens: usize,
    pub cost_usd: f64,
}

/// Unified model session trait
#[async_trait]
pub trait ModelSession: Send + Sync {
    /// Stream a prediction
    async fn predict_stream(
        &self,
        prompt: &str,
    ) -> Result<tokio::sync::mpsc::Receiver<Result<String>>>;

    /// Get a complete prediction (non-streaming)
    async fn predict(&self, prompt: &str) -> Result<(String, Usage)>;

    /// Generate an explanation
    async fn explain(&self, code: &str, depth: &str) -> Result<Explanation>;

    /// Check health
    async fn health(&self) -> Result<bool>;

    /// Get provider name
    fn provider_name(&self) -> &str;
}

/// Unified model adapter
pub enum UnifiedAdapter {
    OpenAI(OpenAIAdapter),
    Anthropic(AnthropicAdapter),
    Google(GoogleAdapter),
}

impl UnifiedAdapter {
    /// Create adapter from configuration
    pub fn from_config(config: AdapterConfig) -> Result<Self> {
        match config {
            AdapterConfig::OpenAI(config) => {
                Ok(UnifiedAdapter::OpenAI(OpenAIAdapter::new(config)?))
            }
            AdapterConfig::Anthropic(config) => {
                Ok(UnifiedAdapter::Anthropic(AnthropicAdapter::new(config)?))
            }
            AdapterConfig::Google(config) => {
                Ok(UnifiedAdapter::Google(GoogleAdapter::new(config)?))
            }
        }
    }

    /// Create a session
    pub fn create_session(self) -> Box<dyn ModelSession> {
        match self {
            UnifiedAdapter::OpenAI(adapter) => Box::new(OpenAISession { adapter }),
            UnifiedAdapter::Anthropic(adapter) => Box::new(AnthropicSession { adapter }),
            UnifiedAdapter::Google(adapter) => Box::new(GoogleSession { adapter }),
        }
    }
}

/// OpenAI session implementation
struct OpenAISession {
    adapter: OpenAIAdapter,
}

#[async_trait]
impl ModelSession for OpenAISession {
    async fn predict_stream(
        &self,
        prompt: &str,
    ) -> Result<tokio::sync::mpsc::Receiver<Result<String>>> {
        let messages = vec![OpenAIMessage {
            role: "user".to_string(),
            content: prompt.to_string(),
            name: None,
            function_call: None,
        }];

        self.adapter.chat_completion_stream(messages).await
    }

    async fn predict(&self, prompt: &str) -> Result<(String, Usage)> {
        let messages = vec![OpenAIMessage {
            role: "user".to_string(),
            content: prompt.to_string(),
            name: None,
            function_call: None,
        }];

        let (message, usage) = self.adapter.chat_completion(messages, None).await?;

        let cost = self.adapter.calculate_cost(&usage);

        Ok((
            message.content,
            Usage {
                input_tokens: usage.prompt_tokens,
                output_tokens: usage.completion_tokens,
                total_tokens: usage.total_tokens,
                cost_usd: cost,
            },
        ))
    }

    async fn explain(&self, code: &str, _depth: &str) -> Result<Explanation> {
        let prompt = format!("Explain this code in detail:\n\n{}", code);
        let (response, _) = self.predict(&prompt).await?;

        Ok(Explanation {
            summary: response.lines().take(3).collect::<Vec<_>>().join(" "),
            details: response.lines().map(|s| s.to_string()).collect(),
            examples: vec![],
        })
    }

    async fn health(&self) -> Result<bool> {
        // Simple health check - try a minimal request
        let result = self.predict("test").await;
        Ok(result.is_ok())
    }

    fn provider_name(&self) -> &str {
        "OpenAI"
    }
}

/// Anthropic session implementation
struct AnthropicSession {
    adapter: AnthropicAdapter,
}

#[async_trait]
impl ModelSession for AnthropicSession {
    async fn predict_stream(
        &self,
        prompt: &str,
    ) -> Result<tokio::sync::mpsc::Receiver<Result<String>>> {
        let messages = vec![AnthropicMessage {
            role: "user".to_string(),
            content: vec![ContentBlock::Text {
                text: prompt.to_string(),
            }],
        }];

        self.adapter.messages_stream(messages, None).await
    }

    async fn predict(&self, prompt: &str) -> Result<(String, Usage)> {
        let messages = vec![AnthropicMessage {
            role: "user".to_string(),
            content: vec![ContentBlock::Text {
                text: prompt.to_string(),
            }],
        }];

        let (content_blocks, usage) = self.adapter.messages(messages, None, None).await?;

        let mut text = String::new();
        for block in content_blocks {
            if let ContentBlock::Text { text: t } = block {
                text.push_str(&t);
            }
        }

        let cost = self.adapter.calculate_cost(&usage);

        Ok((
            text,
            Usage {
                input_tokens: usage.input_tokens,
                output_tokens: usage.output_tokens,
                total_tokens: usage.input_tokens + usage.output_tokens,
                cost_usd: cost,
            },
        ))
    }

    async fn explain(&self, code: &str, _depth: &str) -> Result<Explanation> {
        let prompt = format!("Explain this code in detail:\n\n{}", code);
        let (response, _) = self.predict(&prompt).await?;

        Ok(Explanation {
            summary: response.lines().take(3).collect::<Vec<_>>().join(" "),
            details: response.lines().map(|s| s.to_string()).collect(),
            examples: vec![],
        })
    }

    async fn health(&self) -> Result<bool> {
        let result = self.predict("test").await;
        Ok(result.is_ok())
    }

    fn provider_name(&self) -> &str {
        "Anthropic"
    }
}

/// Google session implementation
struct GoogleSession {
    adapter: GoogleAdapter,
}

#[async_trait]
impl ModelSession for GoogleSession {
    async fn predict_stream(
        &self,
        prompt: &str,
    ) -> Result<tokio::sync::mpsc::Receiver<Result<String>>> {
        let contents = vec![GoogleContent {
            role: "user".to_string(),
            parts: vec![GooglePart::Text {
                text: prompt.to_string(),
            }],
        }];

        self.adapter.generate_content_stream(contents).await
    }

    async fn predict(&self, prompt: &str) -> Result<(String, Usage)> {
        let contents = vec![GoogleContent {
            role: "user".to_string(),
            parts: vec![GooglePart::Text {
                text: prompt.to_string(),
            }],
        }];

        let (content, usage_opt) = self.adapter.generate_content(contents).await?;

        let mut text = String::new();
        for part in content.parts {
            if let GooglePart::Text { text: t } = part {
                text.push_str(&t);
            }
        }

        let usage = if let Some(u) = usage_opt {
            Usage {
                input_tokens: u.prompt_token_count,
                output_tokens: u.candidates_token_count,
                total_tokens: u.total_token_count,
                cost_usd: self.adapter.calculate_cost(&u),
            }
        } else {
            Usage {
                input_tokens: 0,
                output_tokens: 0,
                total_tokens: 0,
                cost_usd: 0.0,
            }
        };

        Ok((text, usage))
    }

    async fn explain(&self, code: &str, _depth: &str) -> Result<Explanation> {
        let prompt = format!("Explain this code in detail:\n\n{}", code);
        let (response, _) = self.predict(&prompt).await?;

        Ok(Explanation {
            summary: response.lines().take(3).collect::<Vec<_>>().join(" "),
            details: response.lines().map(|s| s.to_string()).collect(),
            examples: vec![],
        })
    }

    async fn health(&self) -> Result<bool> {
        let result = self.predict("test").await;
        Ok(result.is_ok())
    }

    fn provider_name(&self) -> &str {
        "Google"
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_unified_adapter_creation() {
        let config = AdapterConfig::OpenAI(OpenAIConfig {
            api_key: "test-key".to_string(),
            ..Default::default()
        });

        let adapter = UnifiedAdapter::from_config(config);
        assert!(adapter.is_ok());
    }
}
