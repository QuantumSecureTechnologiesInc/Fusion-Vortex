use anyhow::Result;
use std::collections::HashMap;
use std::path::{Path, PathBuf};

/// Multi-file editor for atomic cross-file changes
pub struct MultiFileEditor {
    pending_changes: HashMap<PathBuf, Vec<FileEdit>>,
    backups: HashMap<PathBuf, String>,
}

#[derive(Debug, Clone)]
pub struct FileEdit {
    pub line: usize,
    pub operation: EditOperation,
}

#[derive(Debug, Clone)]
pub enum EditOperation {
    Insert { content: String },
    Replace { old: String, new: String },
    Delete { lines: usize },
}

#[derive(Debug, Clone)]
pub struct MultiFileChange {
    pub files: Vec<PathBuf>,
    pub description: String,
    pub edits: HashMap<PathBuf, Vec<FileEdit>>,
}

impl MultiFileEditor {
    pub fn new() -> Self {
        Self {
            pending_changes: HashMap::new(),
            backups: HashMap::new(),
        }
    }

    /// Add an edit to a file
    pub fn add_edit(&mut self, file: PathBuf, edit: FileEdit) {
        self.pending_changes
            .entry(file)
            .or_insert_with(Vec::new)
            .push(edit);
    }

    /// Add multiple edits for a file
    pub fn add_edits(&mut self, file: PathBuf, edits: Vec<FileEdit>) {
        self.pending_changes
            .entry(file)
            .or_insert_with(Vec::new)
            .extend(edits);
    }

    /// Preview all pending changes
    pub fn preview(&self) -> Result<String> {
        let mut preview = String::new();
        preview.push_str("=== Pending Multi-File Changes ===\n\n");

        for (file, edits) in &self.pending_changes {
            preview.push_str(&format!("📝 {}\n", file.display()));
            preview.push_str(&format!("   {} edits\n\n", edits.len()));

            for (idx, edit) in edits.iter().enumerate() {
                preview.push_str(&format!("   Edit #{}: Line {}\n", idx + 1, edit.line));
                match &edit.operation {
                    EditOperation::Insert { content } => {
                        preview.push_str(&format!("   + {}\n", content));
                    }
                    EditOperation::Replace { old, new } => {
                        preview.push_str(&format!("   - {}\n", old));
                        preview.push_str(&format!("   + {}\n", new));
                    }
                    EditOperation::Delete { lines } => {
                        preview.push_str(&format!("   - Delete {} lines\n", lines));
                    }
                }
                preview.push('\n');
            }
        }

        Ok(preview)
    }

    /// Apply all pending changes atomically
    pub fn apply(&mut self) -> Result<Vec<PathBuf>> {
        // First, backup all files
        for file in self.pending_changes.keys() {
            if file.exists() {
                let content = std::fs::read_to_string(file)?;
                self.backups.insert(file.clone(), content);
            }
        }

        let mut modified_files = Vec::new();

        // Apply changes
        for (file, edits) in &self.pending_changes {
            if let Err(e) = self.apply_file_edits(file, edits) {
                // Rollback on error
                self.rollback()?;
                return Err(e);
            }
            modified_files.push(file.clone());
        }

        // Clear pending changes on success
        self.pending_changes.clear();
        self.backups.clear();

        Ok(modified_files)
    }

    fn apply_file_edits(&self, file: &Path, edits: &[FileEdit]) -> Result<()> {
        let content = if file.exists() {
            std::fs::read_to_string(file)?
        } else {
            String::new()
        };

        let mut lines: Vec<String> = content.lines().map(String::from).collect();

        // Sort edits by line number (reverse order to maintain line numbers)
        let mut sorted_edits = edits.to_vec();
        sorted_edits.sort_by(|a, b| b.line.cmp(&a.line));

        for edit in sorted_edits {
            match &edit.operation {
                EditOperation::Insert { content } => {
                    if edit.line <= lines.len() {
                        lines.insert(edit.line, content.clone());
                    } else {
                        lines.push(content.clone());
                    }
                }
                EditOperation::Replace { new, .. } => {
                    if edit.line > 0 && edit.line <= lines.len() {
                        lines[edit.line - 1] = new.clone();
                    }
                }
                EditOperation::Delete { lines: count } => {
                    if edit.line > 0 && edit.line <= lines.len() {
                        let end = (edit.line - 1 + count).min(lines.len());
                        lines.drain((edit.line - 1)..end);
                    }
                }
            }
        }

        let new_content = lines.join("\n");
        std::fs::write(file, new_content)?;

        Ok(())
    }

    fn rollback(&self) -> Result<()> {
        tracing::warn!("Rolling back multi-file changes");

        for (file, content) in &self.backups {
            std::fs::write(file, content)?;
        }

        Ok(())
    }

    /// Create a change set from refactoring description
    pub fn from_refactoring(description: &str, files: Vec<PathBuf>) -> MultiFileChange {
        MultiFileChange {
            files,
            description: description.to_string(),
            edits: HashMap::new(),
        }
    }

    /// Get pending changes count
    pub fn pending_count(&self) -> usize {
        self.pending_changes.len()
    }

    /// Clear all pending changes
    pub fn clear(&mut self) {
        self.pending_changes.clear();
        self.backups.clear();
    }
}

impl Default for MultiFileEditor {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    #[test]
    fn test_multi_file_editor() {
        let mut editor = MultiFileEditor::new();

        // Create temp file
        let mut temp_file = NamedTempFile::new().unwrap();
        writeln!(temp_file, "line 1").unwrap();
        writeln!(temp_file, "line 2").unwrap();
        writeln!(temp_file, "line 3").unwrap();

        let path = temp_file.path().to_path_buf();

        // Add edit
        editor.add_edit(
            path.clone(),
            FileEdit {
                line: 2,
                operation: EditOperation::Replace {
                    old: "line 2".to_string(),
                    new: "modified line 2".to_string(),
                },
            },
        );

        assert_eq!(editor.pending_count(), 1);

        // Preview
        let preview = editor.preview().unwrap();
        assert!(preview.contains("modified line 2"));
    }

    #[test]
    fn test_edit_operations() {
        let edit = FileEdit {
            line: 1,
            operation: EditOperation::Insert {
                content: "new line".to_string(),
            },
        };

        matches!(edit.operation, EditOperation::Insert { .. });
    }
}
