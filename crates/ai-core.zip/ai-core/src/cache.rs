use std::collections::HashMap;
use std::time::{Duration, Instant};

/// Cache entry
#[derive(Clone)]
struct CacheEntry<T> {
    value: T,
    inserted_at: Instant,
    ttl: Duration,
}

/// Simple in-memory cache with TTL
pub struct Cache<T: Clone> {
    entries: HashMap<String, CacheEntry<T>>,
}

impl<T: Clone> Cache<T> {
    pub fn new() -> Self {
        Self {
            entries: HashMap::new(),
        }
    }
    
    pub fn insert(&mut self, key: String, value: T, ttl: Duration) {
        self.entries.insert(
            key,
            CacheEntry {
                value,
                inserted_at: Instant::now(),
                ttl,
            },
        );
    }
    
    pub fn get(&mut self, key: &str) -> Option<T> {
        if let Some(entry) = self.entries.get(key) {
            if entry.inserted_at.elapsed() < entry.ttl {
                return Some(entry.value.clone());
            } else {
                // Expired, remove
                self.entries.remove(key);
            }
        }
        None
    }
    
    pub fn clear(&mut self) {
        self.entries.clear();
    }
}

impl<T: Clone> Default for Cache<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::thread;

    #[test]
    fn test_cache_insert_and_get() {
        let mut cache = Cache::new();
        cache.insert("key1".to_string(), "value1".to_string(), Duration::from_secs(10));
        
        let value = cache.get("key1");
        assert_eq!(value, Some("value1".to_string()));
    }

    #[test]
    fn test_cache_ttl() {
        let mut cache = Cache::new();
        cache.insert("key1".to_string(), "value1".to_string(), Duration::from_millis(50));
        
        thread::sleep(Duration::from_millis(100));
        
        let value = cache.get("key1");
        assert_eq!(value, None);
    }
}
